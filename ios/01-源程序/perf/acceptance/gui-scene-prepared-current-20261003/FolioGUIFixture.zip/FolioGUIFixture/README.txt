全部材料均为虚构。请通过 Files 系统选择器打开 folio-gui.md，再明确选择 FolioGUIFixture 授权图片目录。
